package cliente.login.gui;

public enum LoginControl {
	INVALID_LOGIN,
	INVALID_IP,
	INVALID_PORT,
}
